import { describe, expect, it, beforeEach } from "vitest";
import { getDb } from "./db";
import {
  getOrCreateWallet,
  getWalletBalance,
  recordDeposit,
  recordWithdrawal,
  recordBet,
  recordWin,
  getTransactionHistory,
  getWalletStats,
} from "./wallet";
import { users } from "../drizzle/schema";
import { eq } from "drizzle-orm";

describe("Wallet Management System", () => {
  let testUserId: number;

  beforeEach(async () => {
    const db = await getDb();
    if (!db) return;

    const uniqueId = `test-${Date.now()}-${Math.random()}`;
    await db.insert(users).values({
      openId: uniqueId,
      name: "Test User",
      email: "test@example.com",
    });

    const inserted = await db
      .select()
      .from(users)
      .where(eq(users.openId, uniqueId))
      .limit(1);

    testUserId = inserted[0]?.id || 1;
  });

  describe("Wallet Creation", () => {
    it("creates a new wallet for a user", async () => {
      const wallet = await getOrCreateWallet(testUserId);

      expect(wallet).toBeDefined();
      expect(wallet.userId).toBe(testUserId);
      expect(wallet.balance).toBe("0");
    });

    it("returns existing wallet for user", async () => {
      const wallet1 = await getOrCreateWallet(testUserId);
      const wallet2 = await getOrCreateWallet(testUserId);

      expect(wallet1.id).toBe(wallet2.id);
    });
  });

  describe("Balance Queries", () => {
    it("returns initial balance of 0", async () => {
      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe("0");
    });
  });

  describe("Deposit Transactions", () => {
    it("records a deposit and updates balance", async () => {
      const depositAmount = "100.50";
      const txn = await recordDeposit(testUserId, depositAmount);

      expect(txn.type).toBe("deposit");
      expect(txn.amount).toBe(depositAmount);
      expect(txn.balanceBefore).toBe("0");
      expect(txn.balanceAfter).toBe(depositAmount);

      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe(depositAmount);
    });

    it("records multiple deposits correctly", async () => {
      await recordDeposit(testUserId, "50");
      await recordDeposit(testUserId, "30.25");

      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe("80.25");
    });
  });

  describe("Withdrawal Transactions", () => {
    it("records a withdrawal and updates balance", async () => {
      await recordDeposit(testUserId, "100");
      const txn = await recordWithdrawal(testUserId, "30");

      expect(txn.type).toBe("withdrawal");
      expect(txn.amount).toBe("30");
      expect(txn.balanceBefore).toBe("100");
      expect(txn.balanceAfter).toBe("70");

      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe("70");
    });

    it("prevents withdrawal with insufficient balance", async () => {
      await recordDeposit(testUserId, "50");

      expect(async () => {
        await recordWithdrawal(testUserId, "100");
      }).rejects.toThrow("Insufficient balance");
    });
  });

  describe("Bet Transactions", () => {
    it("records a bet and deducts balance", async () => {
      await recordDeposit(testUserId, "100");
      const txn = await recordBet(testUserId, "25", "dice", 1);

      expect(txn.type).toBe("bet");
      expect(txn.amount).toBe("25");
      expect(txn.balanceBefore).toBe("100");
      expect(txn.balanceAfter).toBe("75");

      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe("75");
    });

    it("prevents bet with insufficient balance", async () => {
      await recordDeposit(testUserId, "20");

      expect(async () => {
        await recordBet(testUserId, "50", "dice", 1);
      }).rejects.toThrow("Insufficient balance");
    });
  });

  describe("Win Transactions", () => {
    it("records a win and credits balance", async () => {
      await recordDeposit(testUserId, "100");
      await recordBet(testUserId, "25", "dice", 1);
      const txn = await recordWin(testUserId, "50", "dice", 1);

      expect(txn.type).toBe("win");
      expect(txn.amount).toBe("50");
      expect(txn.balanceBefore).toBe("75");
      expect(txn.balanceAfter).toBe("125");

      const balance = await getWalletBalance(testUserId);
      expect(balance).toBe("125");
    });
  });

  describe("Transaction History", () => {
    it("retrieves transaction history in order", async () => {
      await recordDeposit(testUserId, "100");
      await recordBet(testUserId, "25", "dice", 1);
      await recordWin(testUserId, "50", "dice", 1);

      const history = await getTransactionHistory(testUserId);

      expect(history.length).toBe(3);
      expect(history[0].type).toBe("deposit");
      expect(history[1].type).toBe("bet");
      expect(history[2].type).toBe("win");
    });

    it("respects limit and offset parameters", async () => {
      for (let i = 0; i < 5; i++) {
        await recordDeposit(testUserId, "10");
      }

      const page1 = await getTransactionHistory(testUserId, 2, 0);
      const page2 = await getTransactionHistory(testUserId, 2, 2);

      expect(page1.length).toBe(2);
      expect(page2.length).toBe(2);
      expect(page1[0].id).not.toBe(page2[0].id);
    });
  });

  describe("Wallet Statistics", () => {
    it("calculates correct statistics", async () => {
      await recordDeposit(testUserId, "100");
      await recordBet(testUserId, "25", "dice", 1);
      await recordWin(testUserId, "50", "dice", 1);
      await recordWithdrawal(testUserId, "30");

      const stats = await getWalletStats(testUserId);

      expect(stats.balance).toBe("95");
      expect(stats.totalDeposited).toBe("100");
      expect(stats.totalWithdrawn).toBe("30");
      expect(stats.totalWagered).toBe("25");
      expect(stats.totalWon).toBe("50");
      expect(stats.netProfit).toBe("25");
    });
  });

  describe("Decimal Precision", () => {
    it("handles decimal amounts correctly", async () => {
      await recordDeposit(testUserId, "100.12345");
      await recordBet(testUserId, "25.67890", "dice", 1);
      await recordWin(testUserId, "50.11111", "dice", 1);

      const balance = await getWalletBalance(testUserId);
      const numBalance = parseFloat(balance);
      expect(numBalance).toBeCloseTo(124.55566, 5);
    });
  });
});
