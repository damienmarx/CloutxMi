import { eq } from "drizzle-orm";
import { getDb } from "./db";
import { wallets, transactions, users } from "../drizzle/schema";
import type { Wallet, Transaction } from "../drizzle/schema";
import Decimal from "decimal.js";

/**
 * Wallet Management System
 * Handles user balances, deposits, withdrawals, and transaction history
 */

/**
 * Create or get a wallet for a user
 */
export async function getOrCreateWallet(userId: number): Promise<Wallet> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Try to find existing wallet
  const existing = await db
    .select()
    .from(wallets)
    .where(eq(wallets.userId, userId))
    .limit(1);

  if (existing.length > 0) {
    return existing[0];
  }

  // Create new wallet
  await db.insert(wallets).values({
    userId,
    balance: "0",
    totalDeposited: "0",
    totalWithdrawn: "0",
    totalWagered: "0",
    totalWon: "0",
  });

  const newWallet = await db
    .select()
    .from(wallets)
    .where(eq(wallets.userId, userId))
    .limit(1);

  return newWallet[0];
}

/**
 * Get wallet balance for a user
 */
export async function getWalletBalance(userId: number): Promise<string> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await db
    .select()
    .from(wallets)
    .where(eq(wallets.userId, userId))
    .limit(1);

  return wallet.length > 0 ? wallet[0].balance : "0";
}

/**
 * Record a deposit transaction
 */
export async function recordDeposit(
  userId: number,
  amount: string,
  description?: string
): Promise<Transaction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);
  const balanceBefore = new Decimal(wallet.balance);
  const depositAmount = new Decimal(amount);
  const balanceAfter = balanceBefore.plus(depositAmount);

  // Record transaction
  await db.insert(transactions).values({
    userId,
    walletId: wallet.id,
    type: "deposit",
    amount: amount,
    balanceBefore: balanceBefore.toString(),
    balanceAfter: balanceAfter.toString(),
    description: description || "Deposit",
  });

  // Update wallet
  await db
    .update(wallets)
    .set({
      balance: balanceAfter.toString(),
      totalDeposited: new Decimal(wallet.totalDeposited).plus(depositAmount).toString(),
    })
    .where(eq(wallets.id, wallet.id));

  // Return the transaction
  const txns = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(1);

  return txns[0];
}

/**
 * Record a withdrawal transaction
 */
export async function recordWithdrawal(
  userId: number,
  amount: string,
  description?: string
): Promise<Transaction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);
  const balanceBefore = new Decimal(wallet.balance);
  const withdrawAmount = new Decimal(amount);

  if (balanceBefore.lessThan(withdrawAmount)) {
    throw new Error("Insufficient balance for withdrawal");
  }

  const balanceAfter = balanceBefore.minus(withdrawAmount);

  // Record transaction
  await db.insert(transactions).values({
    userId,
    walletId: wallet.id,
    type: "withdrawal",
    amount: amount,
    balanceBefore: balanceBefore.toString(),
    balanceAfter: balanceAfter.toString(),
    description: description || "Withdrawal",
  });

  // Update wallet
  await db
    .update(wallets)
    .set({
      balance: balanceAfter.toString(),
      totalWithdrawn: new Decimal(wallet.totalWithdrawn).plus(withdrawAmount).toString(),
    })
    .where(eq(wallets.id, wallet.id));

  // Return the transaction
  const txns = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(1);

  return txns[0];
}

/**
 * Record a bet transaction (balance deduction)
 */
export async function recordBet(
  userId: number,
  amount: string,
  gameId: string,
  betId: number,
  description?: string
): Promise<Transaction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);
  const balanceBefore = new Decimal(wallet.balance);
  const betAmount = new Decimal(amount);

  if (balanceBefore.lessThan(betAmount)) {
    throw new Error("Insufficient balance to place bet");
  }

  const balanceAfter = balanceBefore.minus(betAmount);

  // Record transaction
  await db.insert(transactions).values({
    userId,
    walletId: wallet.id,
    type: "bet",
    amount: amount,
    balanceBefore: balanceBefore.toString(),
    balanceAfter: balanceAfter.toString(),
    gameId,
    betId,
    description: description || "Bet placed",
  });

  // Update wallet
  await db
    .update(wallets)
    .set({
      balance: balanceAfter.toString(),
      totalWagered: new Decimal(wallet.totalWagered).plus(betAmount).toString(),
    })
    .where(eq(wallets.id, wallet.id));

  // Return the transaction
  const txns = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(1);

  return txns[0];
}

/**
 * Record a win transaction (balance credit)
 */
export async function recordWin(
  userId: number,
  amount: string,
  gameId: string,
  betId: number,
  description?: string
): Promise<Transaction> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);
  const balanceBefore = new Decimal(wallet.balance);
  const winAmount = new Decimal(amount);
  const balanceAfter = balanceBefore.plus(winAmount);

  // Record transaction
  await db.insert(transactions).values({
    userId,
    walletId: wallet.id,
    type: "win",
    amount: amount,
    balanceBefore: balanceBefore.toString(),
    balanceAfter: balanceAfter.toString(),
    gameId,
    betId,
    description: description || "Win credited",
  });

  // Update wallet
  await db
    .update(wallets)
    .set({
      balance: balanceAfter.toString(),
      totalWon: new Decimal(wallet.totalWon).plus(winAmount).toString(),
    })
    .where(eq(wallets.id, wallet.id));

  // Return the transaction
  const txns = await db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(1);

  return txns[0];
}

/**
 * Get transaction history for a user
 */
export async function getTransactionHistory(
  userId: number,
  limit: number = 50,
  offset: number = 0
): Promise<Transaction[]> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return db
    .select()
    .from(transactions)
    .where(eq(transactions.userId, userId))
    .orderBy((t) => t.createdAt)
    .limit(limit)
    .offset(offset);
}

/**
 * Get wallet statistics
 */
export async function getWalletStats(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const wallet = await getOrCreateWallet(userId);

  return {
    balance: wallet.balance,
    totalDeposited: wallet.totalDeposited,
    totalWithdrawn: wallet.totalWithdrawn,
    totalWagered: wallet.totalWagered,
    totalWon: wallet.totalWon,
    netProfit: new Decimal(wallet.totalWon)
      .minus(wallet.totalWagered)
      .toString(),
  };
}
