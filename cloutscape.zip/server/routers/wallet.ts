import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  getOrCreateWallet,
  getWalletBalance,
  recordDeposit,
  recordWithdrawal,
  getTransactionHistory,
  getWalletStats,
} from "../wallet";
import { TRPCError } from "@trpc/server";

export const walletRouter = router({
  /**
   * Get current wallet balance
   */
  getBalance: protectedProcedure.query(async ({ ctx }) => {
    try {
      const balance = await getWalletBalance(ctx.user.id);
      return { balance };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch balance",
      });
    }
  }),

  /**
   * Get wallet statistics
   */
  getStats: protectedProcedure.query(async ({ ctx }) => {
    try {
      const stats = await getWalletStats(ctx.user.id);
      return stats;
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Failed to fetch wallet statistics",
      });
    }
  }),

  /**
   * Get transaction history with pagination
   */
  getHistory: protectedProcedure
    .input(
      z.object({
        limit: z.number().int().min(1).max(100).default(50),
        offset: z.number().int().min(0).default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      try {
        const transactions = await getTransactionHistory(
          ctx.user.id,
          input.limit,
          input.offset
        );
        return { transactions };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to fetch transaction history",
        });
      }
    }),

  /**
   * Deposit funds (admin only for now)
   */
  deposit: protectedProcedure
    .input(
      z.object({
        amount: z.string().regex(/^\d+(\.\d{1,8})?$/),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        // In production, verify this is a legitimate deposit (payment gateway, etc.)
        const txn = await recordDeposit(ctx.user.id, input.amount, input.description);
        return { success: true, transaction: txn };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to record deposit",
        });
      }
    }),

  /**
   * Withdraw funds (with balance check)
   */
  withdraw: protectedProcedure
    .input(
      z.object({
        amount: z.string().regex(/^\d+(\.\d{1,8})?$/),
        description: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const txn = await recordWithdrawal(
          ctx.user.id,
          input.amount,
          input.description
        );
        return { success: true, transaction: txn };
      } catch (error) {
        if (error instanceof Error && error.message.includes("Insufficient")) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "Insufficient balance for withdrawal",
          });
        }
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to process withdrawal",
        });
      }
    }),
});
