import { z } from "zod";
import { protectedProcedure, publicProcedure, router } from "../_core/trpc";
import {
  generateServerSeed,
  hashServerSeed,
  generateDiceOutcome,
  generateCrashOutcome,
  generateCoinflipOutcome,
  createFairnessProof,
  verifyFairnessProof,
} from "../gameEngine";
import { TRPCError } from "@trpc/server";

export const gamesRouter = router({
  /**
   * Initialize a new game round with server seed
   */
  initializeRound: protectedProcedure
    .input(
      z.object({
        gameId: z.string(),
        clientSeed: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const serverSeed = generateServerSeed();
        const serverSeedHash = hashServerSeed(serverSeed);

        return {
          serverSeedHash,
          clientSeed: input.clientSeed || "",
          nonce: 0,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to initialize game round",
        });
      }
    }),

  /**
   * Generate dice game outcome
   */
  playDice: protectedProcedure
    .input(
      z.object({
        serverSeed: z.string(),
        clientSeed: z.string(),
        nonce: z.number().int().min(0),
        targetNumber: z.number().int().min(0).max(99),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const outcome = generateDiceOutcome(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          input.targetNumber
        );

        const proof = createFairnessProof(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          outcome
        );

        return {
          outcome,
          proof,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to generate dice outcome",
        });
      }
    }),

  /**
   * Generate crash game outcome
   */
  playCrash: protectedProcedure
    .input(
      z.object({
        serverSeed: z.string(),
        clientSeed: z.string(),
        nonce: z.number().int().min(0),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const outcome = generateCrashOutcome(
          input.serverSeed,
          input.clientSeed,
          input.nonce
        );

        const proof = createFairnessProof(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          outcome
        );

        return {
          outcome,
          proof,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to generate crash outcome",
        });
      }
    }),

  /**
   * Generate coinflip game outcome
   */
  playCoinflip: protectedProcedure
    .input(
      z.object({
        serverSeed: z.string(),
        clientSeed: z.string(),
        nonce: z.number().int().min(0),
        playerChoice: z.enum(["heads", "tails"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      try {
        const outcome = generateCoinflipOutcome(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          input.playerChoice
        );

        const proof = createFairnessProof(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          outcome
        );

        return {
          outcome,
          proof,
        };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to generate coinflip outcome",
        });
      }
    }),

  /**
   * Verify fairness of a game outcome (public endpoint)
   */
  verifyFairness: publicProcedure
    .input(
      z.object({
        serverSeed: z.string(),
        clientSeed: z.string(),
        nonce: z.number().int().min(0),
        gameType: z.enum(["dice", "crash", "coinflip"]),
        outcome: z.unknown(),
      })
    )
    .query(async ({ input }) => {
      try {
        const result = verifyFairnessProof(
          input.serverSeed,
          input.clientSeed,
          input.nonce,
          input.gameType,
          input.outcome
        );

        return result;
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to verify fairness",
        });
      }
    }),

  /**
   * Get server seed hash (reveals after game completion)
   */
  revealServerSeed: protectedProcedure
    .input(
      z.object({
        serverSeed: z.string(),
      })
    )
    .query(async ({ input }) => {
      try {
        const hash = hashServerSeed(input.serverSeed);
        return { hash };
      } catch (error) {
        throw new TRPCError({
          code: "INTERNAL_SERVER_ERROR",
          message: "Failed to hash server seed",
        });
      }
    }),
});
