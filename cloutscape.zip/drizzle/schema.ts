import { bigint, decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, json } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isBanned: boolean("isBanned").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User wallet system for balance tracking and transactions
 */
export const wallets = mysqlTable("wallets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  balance: decimal("balance", { precision: 20, scale: 8 }).notNull().default("0"),
  totalDeposited: decimal("totalDeposited", { precision: 20, scale: 8 }).notNull().default("0"),
  totalWithdrawn: decimal("totalWithdrawn", { precision: 20, scale: 8 }).notNull().default("0"),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).notNull().default("0"),
  totalWon: decimal("totalWon", { precision: 20, scale: 8 }).notNull().default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Wallet = typeof wallets.$inferSelect;
export type InsertWallet = typeof wallets.$inferInsert;

/**
 * Transaction history for deposits, withdrawals, and bet settlements
 */
export const transactions = mysqlTable("transactions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  walletId: int("walletId").notNull(),
  type: mysqlEnum("type", ["deposit", "withdrawal", "bet", "win", "refund"]).notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  balanceBefore: decimal("balanceBefore", { precision: 20, scale: 8 }).notNull(),
  balanceAfter: decimal("balanceAfter", { precision: 20, scale: 8 }).notNull(),
  gameId: varchar("gameId", { length: 64 }),
  betId: int("betId"),
  description: text("description"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Transaction = typeof transactions.$inferSelect;
export type InsertTransaction = typeof transactions.$inferInsert;

/**
 * Game configuration and metadata
 */
export const games = mysqlTable("games", {
  id: varchar("id", { length: 64 }).primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["dice", "crash", "coinflip"]).notNull(),
  description: text("description"),
  houseEdge: decimal("houseEdge", { precision: 5, scale: 2 }).notNull(),
  minBet: decimal("minBet", { precision: 20, scale: 8 }).notNull(),
  maxBet: decimal("maxBet", { precision: 20, scale: 8 }).notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Game = typeof games.$inferSelect;
export type InsertGame = typeof games.$inferInsert;

/**
 * Individual game rounds/sessions
 */
export const gameRounds = mysqlTable("gameRounds", {
  id: varchar("id", { length: 64 }).primaryKey(),
  gameId: varchar("gameId", { length: 64 }).notNull(),
  serverSeed: varchar("serverSeed", { length: 255 }).notNull(),
  serverSeedHash: varchar("serverSeedHash", { length: 255 }).notNull(),
  clientSeed: varchar("clientSeed", { length: 255 }),
  nonce: int("nonce").notNull(),
  outcome: json("outcome"),
  status: mysqlEnum("status", ["pending", "completed", "cancelled"]).default("pending").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
});

export type GameRound = typeof gameRounds.$inferSelect;
export type InsertGameRound = typeof gameRounds.$inferInsert;

/**
 * Individual bets placed by users
 */
export const bets = mysqlTable("bets", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  gameRoundId: varchar("gameRoundId", { length: 64 }).notNull(),
  gameId: varchar("gameId", { length: 64 }).notNull(),
  amount: decimal("amount", { precision: 20, scale: 8 }).notNull(),
  betData: json("betData"),
  result: mysqlEnum("result", ["pending", "win", "loss", "cancelled"]).default("pending").notNull(),
  payout: decimal("payout", { precision: 20, scale: 8 }).default("0"),
  multiplier: decimal("multiplier", { precision: 10, scale: 4 }).default("0"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  settledAt: timestamp("settledAt"),
});

export type Bet = typeof bets.$inferSelect;
export type InsertBet = typeof bets.$inferInsert;

/**
 * Live events for real-time feed (big wins, streaks, etc.)
 */
export const liveEvents = mysqlTable("liveEvents", {
  id: int("id").autoincrement().primaryKey(),
  type: mysqlEnum("type", ["bigWin", "highRoller", "rareOutcome", "streak", "jackpot", "special"]).notNull(),
  userId: int("userId"),
  gameId: varchar("gameId", { length: 64 }),
  betId: int("betId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  metadata: json("metadata"),
  isNotified: boolean("isNotified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LiveEvent = typeof liveEvents.$inferSelect;
export type InsertLiveEvent = typeof liveEvents.$inferInsert;

/**
 * Webhook configurations for Discord and Telegram
 */
export const webhooks = mysqlTable("webhooks", {
  id: int("id").autoincrement().primaryKey(),
  platform: mysqlEnum("platform", ["discord", "telegram"]).notNull(),
  url: text("url").notNull(),
  eventTypes: json("eventTypes").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Webhook = typeof webhooks.$inferSelect;
export type InsertWebhook = typeof webhooks.$inferInsert;

/**
 * Marketing campaign templates
 */
export const marketingCampaigns = mysqlTable("marketingCampaigns", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["launch", "promo", "jackpot", "newGame", "custom"]).notNull(),
  template: text("template").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type MarketingCampaign = typeof marketingCampaigns.$inferSelect;
export type InsertMarketingCampaign = typeof marketingCampaigns.$inferInsert;

/**
 * Platform analytics and statistics
 */
export const platformStats = mysqlTable("platformStats", {
  id: int("id").autoincrement().primaryKey(),
  date: timestamp("date").defaultNow().notNull(),
  totalVolume: decimal("totalVolume", { precision: 20, scale: 8 }).notNull().default("0"),
  totalWagered: decimal("totalWagered", { precision: 20, scale: 8 }).notNull().default("0"),
  totalPayouts: decimal("totalPayouts", { precision: 20, scale: 8 }).notNull().default("0"),
  activePlayerCount: int("activePlayerCount").notNull().default(0),
  totalPlayerCount: int("totalPlayerCount").notNull().default(0),
  gameStats: json("gameStats"),
});

export type PlatformStats = typeof platformStats.$inferSelect;
export type InsertPlatformStats = typeof platformStats.$inferInsert;